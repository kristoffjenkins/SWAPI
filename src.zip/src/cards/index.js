import React, { useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';

/* css */
import './index.css';

/* icons */
import { ReactComponent as CardIcon } from '../Interview Assets/Card.svg';
import { ReactComponent as MaleIcon } from '../Interview Assets/Gender-Male.svg';
import { ReactComponent as FemaleIcon } from '../Interview Assets/Gender-Female.svg';
import { ReactComponent as HomeworldIcon } from '../Interview Assets/Homeworld.svg';
import { ReactComponent as StarshipIcon } from '../Interview Assets/Starship.svg';
import { ReactComponent as VehicleIcon } from '../Interview Assets/Vehicle.svg';






export default function Card({ render }) {
    const history = useHistory();



    const changeRoute = () => {
        history.push('/Deck', render);
    }

 
    return (<>
        <div className="card" onClick={() =>changeRoute()}>
            <div className="card-header">
                <CardIcon />
                <p>{render.name}</p>
            </div>

            <div className="card-body">

                <div className="card-body-header">
                    <span style={{ display: 'flex' }}>
                        {render.gender === 'male' ? <MaleIcon /> : <FemaleIcon />}
                        <p>{render.birthYear}</p>
                    </span>

                    <p>{render.species}</p>
                </div>

                <div className="card-body-panel">
                    <span>
                        <HomeworldIcon />
                        <small>Homeworld</small>

                    </span>

                    <p>{render.homeworld}</p>
                </div>

                <div className="card-body-panel">
                    <span>
                        <StarshipIcon />
                        <small>Spaceships</small>

                    </span>

                    <p>{ render.starships === undefined ? 0 : render.starships.length }</p>
                </div>

                <div className="card-body-panel">
                    <span>
                        <VehicleIcon />
                        <small>Vehicles</small>

                    </span>

                    <p>{render.vehicles === undefined ? 0 : render.vehicles.length}</p>
                </div>


            </div>

        </div>

        {/* <div className="card" onClick={() =>changeRoute()}>
                <div className="card-header">
                    <CardIcon />
                    <p>{render.name}</p>
                </div>

                <div className="card-body">

                    <div className="card-body-header">
                        <span style={{ display: 'flex' }}>
                            {render.gender === 'male' ? <MaleIcon /> : <FemaleIcon />}
                            <p>{render.birthYear}</p>
                        </span>

                        <p>{render.species}</p>
                    </div>

                    <div className="card-body-panel">
                        <span>
                            <HomeworldIcon />
                            <small>Homeworld</small>

                        </span>

                        <p>{render.homeworld}</p>
                    </div>

                    <div className="card-body-panel">
                        <span>
                            <StarshipIcon />
                            <small>Spaceships</small>

                        </span>

                        <p>{render.starships}</p>
                    </div>

                    <div className="card-body-panel">
                        <span>
                            <VehicleIcon />
                            <small>Vehicles</small>

                        </span>

                        <p>{render.vehicles}</p>
                    </div>

                </div>
            </div> */}


    </>)
}
