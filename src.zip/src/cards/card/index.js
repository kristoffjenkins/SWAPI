import React from 'react';

/* css */
import './index.css';

/* icons */
import { ReactComponent as CardIcon } from '../../Interview Assets/Card.svg';
import { ReactComponent as MaleIcon } from '../../Interview Assets/Gender-Male.svg';
import { ReactComponent as FemaleIcon } from '../../Interview Assets/Gender-Female.svg';
import { ReactComponent as HomeworldIcon } from '../../Interview Assets/Homeworld.svg';
import { ReactComponent as StarshipIcon } from '../../Interview Assets/Starship.svg';
import { ReactComponent as VehicleIcon } from '../../Interview Assets/Vehicle.svg';


export default function Index(render) {
    const { name, gender, birthYear, starships, vehicles, homeworld, species} = render.person;


    return (
        <div className="card-single">
            <div className="card-header">
                <CardIcon />
                <p>{name}</p>
            </div>

            <div className="card-body">

                <div className="card-body-header">
                    <span style={{ display: 'flex' }}>
                        {gender === 'male' ? <MaleIcon /> : <FemaleIcon />}
                        <p>{birthYear}</p>
                    </span>

                    <p>{species}</p>
                </div>

                <div className="card-body-panel">
                    <span>
                        <HomeworldIcon />
                        <small>Homeworld</small>

                    </span>

                    <p>{homeworld}</p>
                </div>

                {
                    //starship
                    starships.length > 0 ?
                        starships.map((item, index) => {
                            return (
                                <div className="card-body-panel" key={index}>
                                    <span >
                                        <StarshipIcon />
                                        <small>Starship</small>

                                    </span>

                                    <p >{item.name}</p>
                                </div>

                            )
                        }) :

                        <div className="card-body-panel">
                            <span >
                                <StarshipIcon />
                                <small>Starship</small>

                            </span>

                            <p >{0}</p>
                        </div>

                }

                {
                    //vehicle
                    vehicles.length > 0 ?
                        vehicles.map((item, index) => {
                            return (
                                <div key={index} className="card-body-panel">
                                    <span >
                                        <VehicleIcon />
                                        <small>Vehicle</small>

                                    </span>

                                    <p >{item.name}</p>
                                </div>

                            )
                        }) :

                        <div className="card-body-panel">
                            <span >
                                <VehicleIcon />
                                <small>Vehicle</small>

                            </span>

                            <p >{0}</p>
                        </div>

                }
 

            </div>
        </div>
    )
}
