import axios from 'axios';

export const getDataDynamic = async (url, abort) =>{

    var state = Array.isArray(url);
    const dataArray = [];

    if (state === true){
        url.forEach((uri) =>{
            dataArray.push(axios.get(uri)
                .then((resulst)=>{
                    return resulst.data;
                })
                .catch((err) =>console.error(err.message))
            );
        });

        let resposnse = await Promise.all(dataArray);

        return resposnse;
    } else {
        let resposnse = await axios.get(url);
        return resposnse;
    }
}