import React, {useEffect}from 'react';
import { useLocation } from 'react-router-dom';
import Card from '../cards/card'
import './Deck.css'

export default function Deck({updateBCtext}) {

    const location = useLocation();
    const person = location.state;

    useEffect(()=>{
        updateBCtext(person.name);

        // eslint-disable-next-line
    },[person])
    

    return (
        <div className="card-wrapp">
            <Card person={person}/>
        </div>
    )
}


