import React, { useState, useEffect } from 'react';

/* css */
import './Home.css';

/* icons */
import { ReactComponent as SearchIcon } from '../Interview Assets/Search.svg'

/* card */
import Card from '../cards'

export default function Home({ people }) {

    const [searchList, setSearchList] = useState([]);
    const [orderList, setOrderList] = useState([])
    const [viewOrder, setViewOrder] = useState('ASC')

    useEffect(() => {
        setOrderList(people);
    }, [people, orderList])

    const updateOrder = async (list) => {
        await setOrderList(prev => [...prev, list]);
    }

    /* sort order */
    const handleOrder = (e) => {
        let btnVal = e.target.innerText;
        setViewOrder(btnVal)
    }

    /* sort function */
    const handleSort = () => {
        const sortBy = document.getElementById("sort").value;

        switch (sortBy) {
            case "Homeworld":
                if (viewOrder === "ASC") {
                    console.log("here")
                    let text_compare = (a, b) => {
                        var valueA = a.homeworld;
                        var ValueB = b.homeworld;


                        if (valueA < ValueB) return -1;

                        if (valueA > ValueB) return 1;

                        return 0;

                    }
                    let asc = people.sort(text_compare);
                    updateOrder(asc)

                } else {
                    console.log("descending")
                    let text_compare = (a, b) => {
                        var valueA = a.homeworld;
                        var ValueB = b.homeworld;


                        if (valueA < ValueB) return -1;

                        if (valueA > ValueB) return 1;

                        return 0;

                    }
                    let desc = people.sort(text_compare).reverse();
                    updateOrder(desc);
                }
                break;
            case 'Vehicles':
                console.log("v")

                let num_compare = (a, b) => {
                    var valueA = a.vehicles.lenght;
                    var valueB = b.vehicles.lenght;

                    if (viewOrder === 'ASC') {
                        return valueA - valueB;
                    } else {
                        return valueB - valueA;
                    }


                };

                let sort = people.sort(num_compare);

                updateOrder(sort);



                break;

            case 'Starships':
                console.log("s")

                let num_2compare = (a, b) => {
                    var valueA = a.starships.lenght === undefined ? 0 : a.starships.lenght;
                    var valueB = b.starships.lenght === undefined ? 0 : b.starships.lenght;

                    console.log("valuea", valueA);

                    if (viewOrder === 'ASC') {
                        return valueA - valueB;
                    } else {
                        return valueB - valueA;
                    }


                };

                let sort2 = people.sort(num_2compare);
                console.log(sort2)

                updateOrder(sort2);

                break


        }

    }



    return (
        <div className="main">

            <div className="tool-bar">

                {/* Search bar */}
                <div className="search-container">
                    <input type="text" className="search-bar" placeholder="Search" />
                    <button type="button" className="search-btn" > <SearchIcon fill="white" /> </button>
                </div>

                {/* sort */}
                <div className="sort-container">

                    <p id="sort-lable"> Sort By </p>

                    <div className="btn-main">
                        <div className="select-container">

                            <select id="sort" defaultValue="Homeword" onChange={() => handleSort()}>
                                <option value="Homeworld"> Homeworld</option>
                                <option value="Vehicles"> Vehicles</option>
                                <option value="Starships"> Starships</option>
                            </select>
                        </div>

                        <div className="order-btn-group">
                            <button type="button" className="btn-ASC active" onClick={(e) => handleOrder(e)}> ASC</button>
                            <button type="button" className="btn-DESC" onClick={(e) => handleOrder(e)}> DESC</button>
                        </div>

                    </div>

                </div>

            </div>

            <div className="card-wrapper">

                {orderList.map((item, index) => {

                    return <Card render={item} key={index} />;
                })}

            </div>





        </div>
    )
}
