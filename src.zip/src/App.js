import React, {useEffect, useState} from 'react';
import {Route, Switch, BrowserRouter as Router} from 'react-router-dom';

/* css */
import './App.css';

/* api */
import {getDataDynamic} from './api/api.js';

/* pages */
import Home from './pages/Home';
import Deck from './pages/Deck';

/* Icons */
import { ReactComponent as CardIcon } from './Interview Assets/Card.svg';
import { ReactComponent as DeckIcon} from './Interview Assets/Deck.svg';

const App =() => {
    const abortRequest = new AbortController();
    const [people, setPeople] = useState([]);
    const[breadcrumbText, setbreadcrumbText] = useState("Select a card");
    var generalData = [];

    const updatePeople = (newElement) =>{
        setPeople(newElement)
    }
    
    useEffect(() =>{
        async function getPeopleData(){
            let url = "https://swapi.dev/api/people/";
            


            const peopleApiRes = await getDataDynamic(url,abortRequest)
            .then((response)=>{
                return response.data.results
            });
            /* console.log(peopleApiRes); */
            
            peopleApiRes.forEach(async (person)=>{
                const {species, vehicles, starships, homeworld} = person;



                var speciesData = new Promise(async (resolve, reject)=>{
                    resolve(await getDataDynamic(species, abortRequest))
                });


                var vehiclesData= new Promise(async (resolve, reject)=>{
                    resolve(await getDataDynamic(vehicles, abortRequest))
                });

                var starshipsData = new Promise(async (resolve, reject)=>{
                    resolve(await getDataDynamic(starships, abortRequest))
                });

                var homeworldData = new Promise(async (resolve, reject)=>{
                    resolve(await getDataDynamic(homeworld, abortRequest))
                })

                Promise.all([speciesData, starshipsData, homeworldData,vehiclesData])
                .then((results)=>{
                    /* console.log(results); */

                    let obj = {
                        name: person.name,
                        birthYear : person.birth_year,
                        gender:person.gender,
                        species : results[0].lenght > 0 ? results[0].name : "Human",
                        vehicles : results[3],
                        starships : results[1],
                        homeworld : results[2].data.name
                    }

                    generalData = [...generalData, obj];

                    updatePeople(generalData)

 
                }); 
            });

        }

        getPeopleData();

        return () => abortRequest.abort();
        // eslint-disable-next-line
    },[])

    /* update Breadcrums */
    const updateBCtext = (text) =>{
        setbreadcrumbText(text);
    }

    return (
        <Router>
            {/* Top Nav */}
            <div className="nav">
                <div className="btn-container">
                    <a href="http://localhost:3000/"style={{textDecoration: 'none'}}> <button type="button" id="btn-card"> <CardIcon/> All Cards</button> </a>
                    <button type="button" id="btn-deck"> <DeckIcon/> Deck </button>
                </div>

                <p>SW-<span> API Deck Builder</span></p>

                <input type="button" id="userName" defaultValue="Bavin Edwards" disabled/>

            </div>

            {/* Breadcrumbs */}
            <div className="breadcrumb-container">
                <ul className="breadcrumb-unordered-list">
                    <li className="breadcrumb-list-item"> <a href="http://localhost:3000/"> All Cards </a></li>
                    <li className="breadcrumb-list-item">  {breadcrumbText}</li>
                </ul>
            </div>

            <Switch>
                <Route exact path="/"> <Home people={people}/> </Route> 
                <Route path="/Deck" > <Deck updateBCtext = {updateBCtext} /> </Route> 
            </Switch>
            
        </Router>
    )
}

export default App;